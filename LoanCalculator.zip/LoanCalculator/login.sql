create database employee;
USE employee;
create table signup(
userId varchar(45),
firstName varchar(45) not null,
lastName varchar(45) not null,
password1 varchar(45) not null,
dob date not null,primary key(userId));
select * from signup;
alter table signup modify column dob varchar(10);
delete from signup;
SET SQL_SAFE_UPDATES = 0;