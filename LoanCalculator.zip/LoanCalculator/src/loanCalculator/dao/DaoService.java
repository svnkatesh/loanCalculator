package loanCalculator.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import loanCalculator.bean.LoginBean;
import loanCalculator.bean.SignupBean;

public class DaoService {
	public boolean validate(LoginBean login) throws SQLException {
		// System.out.println(login);
		boolean status = false;
		Connection con;
		ConnectionHandler connectionHandler = new ConnectionHandler();
		con = connectionHandler.getConnection();
		PreparedStatement preparedstatement = con.prepareStatement("select * from signup where userId ='"+login.getUserId()
		+"'and password1 = '"+login.getPassword()+"'");
		//System.out.println(login.getPassword());
		ResultSet rs = preparedstatement.executeQuery();
		//System.out.println(rs);
		status = rs.next();
		return status;

	}

	public boolean signup(SignupBean signupBean, String userId) {
		Connection con;
		ConnectionHandler connectionHandler = new ConnectionHandler();
		try {
			con = connectionHandler.getConnection();
			String query = "insert into signup (userId,firstName,lastName,password1,dob)" + "values(?,?,?,?,?)";

			PreparedStatement preparedstatement = con.prepareStatement(query);
			preparedstatement.setString(1, userId);
			preparedstatement.setString(2, signupBean.getFirstName());
			preparedstatement.setString(3, signupBean.getLastName());
			preparedstatement.setString(4, signupBean.getPassword());
			preparedstatement.setString(5, signupBean.getDob());
			preparedstatement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;

	}
}
