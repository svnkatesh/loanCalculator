package loanCalculator.bean;

public class LoanDetailsBean {
	private String loanAmount;
	private String tenure;
	private String intrestRate;
	
	public String getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(String loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getTenure() {
		return tenure;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	public String getIntrestRate() {
		return intrestRate;
	}
	public void setIntrestRate(String intrestRate) {
		this.intrestRate = intrestRate;
	}
	

}
