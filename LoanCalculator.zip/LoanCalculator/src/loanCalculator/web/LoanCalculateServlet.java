package loanCalculator.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoanCalculateServlet
 */
@WebServlet("/LoanCalculateServlet")
public class LoanCalculateServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int loanAmount = Integer.parseInt(request.getParameter("loanAmount"));
		int tenure = Integer.parseInt(request.getParameter("tenure"));
		int interestRate = Integer.parseInt(request.getParameter("interestRate"));
		double interest;
		interest = (loanAmount*tenure*interestRate*1.0)/100;
		double toatalAmountPaid = loanAmount+interest;
		double totalInterestAmount = interest;
		double totalPrincipleAmount=loanAmount;
		request.setAttribute("totalAmountPaid", toatalAmountPaid);
		request.setAttribute("totalInterestAmount", totalInterestAmount);
		request.setAttribute("totalPrincipleAmount", totalPrincipleAmount);
		request.getRequestDispatcher("display.jsp").forward(request, response);
	}
}
