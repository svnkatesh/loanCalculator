package loanCalculator.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import loanCalculator.bean.SignupBean;
import loanCalculator.dao.DaoService;

/**
 * Servlet implementation class SignupServlet
 */
@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String password = request.getParameter("password");
		String dob = request.getParameter("dob");
		
		String str = "";
		str+=dob.charAt(5);
		str+=dob.charAt(6);
		str+=dob.charAt(8);
		str+=dob.charAt(9);
		String userId = firstName+str;
		SignupBean signupBean = new SignupBean();
		signupBean.setFirstName(firstName);
		signupBean.setLastName(lastName);
		signupBean.setPassword(password);
		signupBean.setDob(dob);
		DaoService loginDao = new DaoService();
		if(loginDao.signup(signupBean, userId))
		{
			request.setAttribute("userId", userId);
			request.getRequestDispatcher("signupSuccess.jsp").forward(request, response);
			//response.sendRedirect("signupSuccess.jsp");
		}
	}

}
