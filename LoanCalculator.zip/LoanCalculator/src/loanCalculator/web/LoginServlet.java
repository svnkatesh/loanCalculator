package loanCalculator.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import loanCalculator.bean.LoginBean;
import loanCalculator.dao.DaoService;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private DaoService loginDao;

	public void init() {
		loginDao = new DaoService();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userId = request.getParameter("userId");
		String password = request.getParameter("password");
		LoginBean login = new LoginBean();
		login.setUserName(userId);
		login.setPassword(password);
		try {
			if (loginDao.validate(login))
				response.sendRedirect("loginSuccess.jsp");
			else
			{
				request.setAttribute("message", "UserId or Password Wrong");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
