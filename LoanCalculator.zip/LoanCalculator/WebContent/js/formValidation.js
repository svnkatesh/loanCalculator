function passwordValidation() {
	var pw = document.getElementById("password").value;
	var pw1 = document.getElementById("confirmPassword").value;
	var firstName = document.getElementById("firstName").value;
	var lastName = document.getElementById("lastName").value;
	if (!isNaN(firstName)) {
		document.getElementById("message1").innerHTML = "Only characters are allowed";
		return false;
	}
	if (!isNaN(lastName)) {
		document.getElementById("message2").innerHTML = "Only characters are allowed";
		return false;
	}
	if (firstName.toLowerCase() == lastName.toLowerCase()) {
		document.getElementById("message2").innerHTML = "First name and last name are same";
		return false;
	}

	if (pw != pw1) {
		document.getElementById("message4").innerHTML = "Password and Confirm Password are mismatch";
		return false;
	} else {
		if (pw.length <= 5) {
			document.getElementById("message3").innerHTML = "Password length is less than or equal to 5";
			return false;
		}
		if (pw.length > 15) {
			document.getElementById("message3").innerHTML = "Password length is greater than 15";
			return false;
		} else {
			return true;
		}
	}
}
(function () {
	setTimeout(function() {
	    document.getElementById('mydiv').innerHTML="";
	}, 5000)  // I will invoke myself
	})();
